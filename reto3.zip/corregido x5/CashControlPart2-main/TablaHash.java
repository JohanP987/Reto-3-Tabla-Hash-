package com.mycompany.cashcontroljava;
import java.util.HashMap;

public class TablaHash {
    private HashMap<String, Usuario> tablaHash;

    public TablaHash() {
        tablaHash = new HashMap<>();
    }

    public void insertarUsuario(Usuario usuario) {
        tablaHash.put(usuario.getNickname(), usuario);
    }

    public Usuario buscarUsuarioPorNickname(String nickname) {
        return tablaHash.get(nickname);
    }
}
